(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Blaze = Package.blaze.Blaze;
var _ = Package.underscore._;
var UI = Package.ui.UI;
var Handlebars = Package.ui.Handlebars;
var Spacebars = Package.spacebars.Spacebars;
var Deps = Package.deps.Deps;
var Iron = Package['iron-core'].Iron;
var HTML = Package.htmljs.HTML;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['iron-dynamic-template'] = {};

})();

//# sourceMappingURL=iron-dynamic-template.js.map
