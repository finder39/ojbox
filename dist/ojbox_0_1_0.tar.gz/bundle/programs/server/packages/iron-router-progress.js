(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['iron-router-progress'] = {};

})();

//# sourceMappingURL=iron-router-progress.js.map
